package com.rbp.movieapp.models;

public enum ERole {
    ROLE_USER,
    ROLE_GUEST,
    ROLE_ADMIN
}
